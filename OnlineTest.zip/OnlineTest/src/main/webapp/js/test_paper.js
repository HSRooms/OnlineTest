/**
 * 
 */

$(document)
		.ready(
				function() {
					$("#submit").hide();
					var currentListSize=0;
					var $questionsList = $("#qutionsList");
					var newItems = [];
					var moduleName = GetURLParameter("moduleName");
					var topicName = GetURLParameter("topicName");
					var courseId= GetURLParameter("courseId");
					var level= GetURLParameter("level");
				    var QuestionModel;
					var url = "http://localhost:9090/evaluation/retrieveQuestionsByTopic?moduleName="
							+ moduleName + "&topicName=" + topicName+"&courseId=" +courseId+"&level="+level;
					$.getJSON(url, function(result) {
						QuestionModel=result;
						$.each(result, function(i, obj) {
							var qutionComponent = "<div class='panel panel-default'>data</div>";
							var qutionName = "<div class='panel-heading'>qutionName</div>"
							var qutionOptions = "<div class='panel-body'>qutionOptions</div>";
							qutionName = qutionName.replace("qutionName",
									obj.questionNumber+". "+obj.questionsName);
							var optionList = "";
							$.each(obj.options, function(i, optionVal) {
								optionList=optionList.concat("<div class='radio'><label><input type='radio' name='optradio"+obj.questionNumber+"' id='"+obj.questionNumber+"' value='"+optionVal+"'>"+optionVal+"</label></div>");
							});
							if (optionList.length > 0) {
								qutionOptions = qutionOptions.replace(
										"qutionOptions", optionList);
							} else {
								qutionOptions = qutionOptions.replace(
										"qutionOptions", "");
							}
							qutionComponent=qutionComponent.replace("data",qutionName+qutionOptions);
							newItems.push(qutionComponent);
							currentListSize++;
						});
						$questionsList.append(newItems.join(""));
						if(currentListSize==QuestionModel.length)
							{
							//$(".previous").hide();
							$(".next").hide();
							$("#submit").show();
							}
					});

					//for selecting options
					$(document).on("click", "input[type=radio]", function() {
						var indexVal=$(this).attr("id");
						var selectedVal=$(this).val();
						$.each(QuestionModel, function(i, obj) {
							if(obj.questionNumber==indexVal)
								{
								obj.selectedAnswer=selectedVal;
								}
						});
					});
					//send data to backend
					$("#submit").click(function(){
						$.ajax({
				            url: '/evaluation/submitTest',
				            type: 'post',
				            dataType: 'text',
				            contentType: 'application/json',
				            success: function (data) {
				              $("#myModal").modal();
				            },
				            error:function(request, status, error)
				            {
				            	alert(status+","+error);
				            },
				            data: JSON.stringify(QuestionModel)
				          
				        });
					})
				});
function GetURLParameter(sParam) {
	var sPageURL = window.location.search.substring(1);
	var sURLVariables = sPageURL.split('&');
	for (var i = 0; i < sURLVariables.length; i++) {
		var sParameterName = sURLVariables[i].split('=');
		if (sParameterName[0] == sParam) {
			return sParameterName[1];
		}
	}
}