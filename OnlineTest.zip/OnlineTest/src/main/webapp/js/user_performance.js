$(document).ready(function() {
var userId =GetURLParameter("userId");
var username =GetURLParameter("username");
var doj=GetURLParameter("doj");
var url="http://localhost:9090/admin/retrieveAssessmentByUser/"+userId;
var $evaluationResult;

$("#userName").text(username);
$("#userId").text(userId);
$("#doj").text(doj);


var QuestionModel;

$.getJSON(url, function(result) {
	    $evaluationResult=result;
	    var courseId=0;
	    var attemptedCount;
	    var hscore;
	    var courseObj;
	    var $moduleDiv="<div class='panel-group dynamicTopics'>" +
	    		"<div class='panel panel-default'>" +
	    		"<div class='panel-heading' style='padding:20px'>" +
	    		"<ul class='list-inline'>" +
	    		"<li class='panel-title' style='float:left'>" +
	    		"<a data-toggle='collapse' href='#replacecollapse'>topcName</a>" +
	    		"</li>" +
	    		"<li style='float:right'>Attempted : acount</li>" +
	    		"<li style='float:right'>Highest Score:hscore</li>" +
	    		"</ul>" +
	    		"</div>" +
	    		"<div id='replacecollapse' class='panel-collapse collapse'>" +
	    		" <ul class='list-inline'style='text-align:center'>scorecards</ul></div>" +
	    		"</div>" +
	    		"</div>";
		
		var scorecards=[];
		var $topicList = $("#bodycontent");
		var newItems = [];
		var $index=0;
		var scorecardNumber=1;
		$.each(result, function(i, obj) {
			
			if(courseId == 0) 
				{
				 courseId=obj.courseId;
				 attemptedCount=1;
				 hscore=obj.totalScore;
				 var userUrl="http://localhost:9090/course/retrieveCourse/"+obj.courseId;
				 $.ajax({url: userUrl, async: false, success: function(course){
					 courseObj=course;
				    }});
				
	     	    
				}
			else if(courseId!=obj.courseId)
				{
				$moduleDiv=$moduleDiv.replace(/replacecollapse/g, "collapse"+$index);
	     		$moduleDiv=$moduleDiv.replace("topcName",courseObj.topicName);
	     		$moduleDiv=$moduleDiv.replace("acount",attemptedCount);
	     		$moduleDiv=$moduleDiv.replace("hscore",hscore);
	     	    $moduleDiv=$moduleDiv.replace("scorecards",scorecards.join(""));
	     	    scorecardNumber=1;
	     	    scorecards=[];
	     	    newItems.push($moduleDiv);
	     	    courseId=obj.courseId;
				attemptedCount=1;
				hscore=obj.totalScore;
				 var userUrl="http://localhost:9090/course/retrieveCourse/"+obj.courseId;
				 $.ajax({url: userUrl, async: false, success: function(course){
					 courseObj=course;
				    }});
	     	    $moduleDiv="<div class='panel-group dynamicTopics'>" +
	    		"<div class='panel panel-default'>" +
	    		"<div class='panel-heading' style='padding:20px'>" +
	    		"<ul class='list-inline'>" +
	    		"<li class='panel-title' style='float:left'>" +
	    		"<a data-toggle='collapse' href='#replacecollapse'>topcName</a>" +
	    		"</li>" +
	    		"<li style='float:right'>Attempted : acount</li>" +
	    		"<li style='float:right'>Highest Score:hscore</li>" +
	    		"</ul>" +
	    		"</div>" +
	    		"<div id='replacecollapse' class='panel-collapse collapse'>" +
	    		" <ul class='list-inline'style='text-align:center'>scorecards</ul></div>" +
	    		"</div>" +
	    		"</div>";
				}
			else
				{
				attemptedCount++;
				if(hscore<obj.totalScore)
					{
					hscore=obj.totalScore;
					}
				}
			$index=i;
			//scorecard reading
			scorecards.push("<li><a href='#' data-toggle='modal' data-target='#test' class='popup_model' value='"+obj.evaluationId+","+courseObj.topicName+"'>Sorecard"+scorecardNumber+"</a></li>")
			scorecardNumber++;
			});
		
		$moduleDiv=$moduleDiv.replace(/replacecollapse/g, "collapse"+$index);
 		$moduleDiv=$moduleDiv.replace("topcName",courseObj.topicName);
 		$moduleDiv=$moduleDiv.replace("acount",attemptedCount);
 		$moduleDiv=$moduleDiv.replace("hscore",hscore);
 	    $moduleDiv=$moduleDiv.replace("scorecards",scorecards.join(""));  
 	    newItems.push($moduleDiv);
		$topicList.append(newItems.join(""));
		});
$(document).on("click", ".popup_model", function() {
	var qustionItems = [];
	$("#myModal").remove();
	var $popupModel="<div id='myModal' class='modal fade' role='dialog'>"+
    "<div class='modal-dialog'>"+
    "<div class='modal-content'><div class='modal-header'><button type='button' class='close' data-dismiss='modal'>&times;</button>"+
    "<h4 class='modal-title'>popupHeader</h4></div> <div class='modal-body'>popupbody" +
    "</div> <div class='modal-footer'>"+
    "<button type='button' class='btn btn-default' data-dismiss='modal'>Close</button></div></div></div>";
    var $popuoSorecard="<div class='text-left' id='bodycontent'>"+
		"<div class='panel-group'>qutionsList"+
		"</div>"+
		"<div>"+
        "<ul class='pager'>"+
				"<!--<li class='previous'><a href='#'>Previous</a></li>"+
				"<li class='next'><a href='#'>Next</a></li>-->"+
				
		"</ul>"+
		"</div>"+
"</div>";
    var topicNameAndEvId=$(this).attr("value").split(",");
    var popupHeader=topicNameAndEvId[1];
	var evaluationId=topicNameAndEvId[0];
	$.each($evaluationResult, function(i, evaluationObj) {
		 var currentListSize=0;
		if(evaluationId==evaluationObj.evaluationId)
			{
			QuestionModel=evaluationObj.scoreCard;
			$.each(evaluationObj.scoreCard, function(i, scorecardObj) {
				//prepare scorecard
				var qutionComponent = "<div class='panel panel-default'>data</div>";
				var qutionName = "<div class='panel-heading'>qutionName</div>"
				var qutionOptions = "<div class='panel-body'>qutionOptions</div>";
				qutionName = qutionName.replace("qutionName",
						(i+1)+". "+scorecardObj.questionName);
				var options=scorecardObj.options.split(",");
				var optionList = "";
				$.each(options, function(j, optionVal) {
					var correctAnswer="";
					if(optionVal==scorecardObj.selectedAnswer)
						{
						correctAnswer="checked";
						}
					optionList=optionList.concat("<div class='radio'><label><input type='radio' name='optradio"+(i+1)+"' id='"+(i+1)+"' value='"+optionVal+"'"+correctAnswer+">"+optionVal+"</label></div>");
				});
				if (optionList.length > 0) {
					qutionOptions = qutionOptions.replace(
							"qutionOptions", optionList);
				} else {
					qutionOptions = qutionOptions.replace(
							"qutionOptions", "");
				}
				qutionComponent=qutionComponent.replace("data",qutionName+qutionOptions);
				qustionItems.push(qutionComponent);
				currentListSize++;
			
			});
			$popuoSorecard=$popuoSorecard.replace("qutionsList",qustionItems.join(""));
			if(currentListSize==QuestionModel.length)
				{
				//$(".previous").hide();
				$(".next").hide();
				$("#submit").show();
				}
			
			}
	});
	$popupModel=$popupModel.replace("popupHeader",popupHeader);
	$popupModel=$popupModel.replace("popupbody",$popuoSorecard);

	$("#popupcontent").append($popupModel);
	$("#myModal").modal();
})

});
function GetURLParameter(sParam) {
	var sPageURL = window.location.search.substring(1);
	var sURLVariables = sPageURL.split('&');
	for (var i = 0; i < sURLVariables.length; i++) {
		var sParameterName = sURLVariables[i].split('=');
		if (sParameterName[0] == sParam) {
			return sParameterName[1];
		}
	}
}