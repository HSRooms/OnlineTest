
$(document).ready(function() {
	const months = ["Jan", "Feb", "Mar","Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Noc", "Dec"];
	
	var $sq=-1;
	$("#saveusers").hide();
	var $userObjects;
	/*Load emp reports*/
	$("#empreports").click(function(){
		$(".dynamicEmployees").remove();
		$(".userForm").remove();
		$("#saveusers").hide();
		var $employeesData = $("#bodycontent");
		var newItems = [];
		var tableTemplate="<table class='table table-hover dynamicEmployees'>" +
				"<thead><tr><th scope='col'>#</th>" +
				"<th scope='col'>Employee Name</th>" +
				"<th scope='col'>Employee Id</th>" +
				"<th scope='col'>Date Of Join</th>" +
				"<th scope='col'></th>" +
				"</tr></thead><tbody>rowdata</tbody></table>"
		$.getJSON("http://localhost:9090/admin/retrieveUsers", function(result) {
			
			$.each(result, function(i, obj) {
				var rowData="<tr><th scope='row'>"+(i+1)+"</th><td>"+obj.userName+"</td><td>"+obj.userId+"</td><td>"+obj.doj+"</td><td><a target='_blank' href='/user_performance.html?userId="+obj.userId+"&username="+obj.userName+"&doj="+obj.doj+"' >View Performance</a></td></tr>";
					newItems.push(rowData);
			});
			tableTemplate=tableTemplate.replace("rowdata",newItems.join(""));
			$employeesData.append(tableTemplate);
		});
	});
	
	/*load all employees*/
	
	var usersFormTemplate=" <div class='userForm'><table class='table table-bordered data-table'>" +
			"   <thead> <th class='data-visible' >sq</th>  <th>Id</th>  <th>Name</th>   <th>Email</th>   <th >Date of join</th> <th >Role</th> <th >Action</th> </thead>  <tbody> </tbody> </table> <br/>"+
	"<form >    <div class='form-group'> <label>Name:</label> <input type='text' name='name' class='form-control' value='' required>" +
	" </div>    <div class='form-group'> <label>UserID:</label><input type='text' name='userid' class='form-control' value='' required>" +
	" </div>    <div class='form-group'> <label>Email:</label><input type='text' name='email' class='form-control' value='' required>" +
	" </div>    <div class='form-group'> <label>Date Of Join:</label><input type='date' name='doj' class='form-control' value='' required>" +
	"</div>  <div class='form-group'> <label> Role:</label> <select class='form-control'><option value='1001'>User</option><option value='1002'>Admin</option></select>"+
	"</div>    <div class='form-group'> <input type='hidden' name='sq' class='form-control' value='' >"+
	"  </div id='save_update'> <button class='btn btn-success save-btn' value='add' >Add</button>  </form></div>" ;
	
	$("#employees").click(function() {
		var $employeesData = $("#bodycontent");
		$(".userForm").remove();
		$(".dynamicEmployees").remove();
		$sq=-1;
		$(".btn-update").hide();
		$employeesData.append(usersFormTemplate);
		$(".data-visible").hide();
		$("#saveusers").show();
		//load users
          $.getJSON("http://localhost:9090/rest/user/retrieveAllUsers", function(result) {
        	  $userObjects=result;
			$.each(result, function(i, obj) {
					 var name = obj.userName;
					 var userid=obj.userId;
					 var email = obj.email;
					 var role = obj.role;
					 var doj = obj.doj;
					 $(".data-table tbody").append("<tr data-sq='' data-name='"+name+"' data-email='"+email+"' data-userid='"+userid+"' data-doj='"+doj+"' data-role='"+role+"'><td class='data-visible'></td><td>"+userid+"</td><td>"+name+"</td><td>"+email+"</td><td>"+doj+"</td><td>"+role+"</td><td><button class='btn btn-info btn-xs btn-edit'>Edit</button><button class='btn btn-danger btn-xs btn-delete'>Delete</button></td></tr>");
					 $(".data-visible").hide();
			});
          });
	});
	
	$(document).on("click", ".save-btn", function(e) {
		var saveOrUpdate=$(".save-btn").attr("value");
		if(saveOrUpdate=="add")
			{
			e.preventDefault();
	        var name = $("input[name='name']").val();
	        var email = $("input[name='email']").val();
	        var userid=$("input[name='userid']").val(); 
	        var doj=new Date($("input[name='doj']").val()); 
	        var role=$("select").val(); 
	    	let formatted_date = doj.getDate() + "-" + months[doj.getMonth()] + "-" + doj.getFullYear();
	        $userObjects.push({"userName":name,"email":email,"userId":userid,"userPw":"password123","role":1001,"doj":formatted_date,updated:true,available:true})
	        $(".data-table tbody").append("<tr data-sq='' data-name='"+name+"' data-email='"+email+"' data-userid='"+userid+"' data-doj='"+formatted_date+"' data-role='"+role+"'><td class='data-visible'></td><td>"+userid+"</td><td>"+name+"</td><td>"+email+"</td><td>"+formatted_date+"</td><td>"+role+"</td><td><button class='btn btn-info btn-xs btn-edit'>Edit</button><button class='btn btn-danger btn-xs btn-delete'>Delete</button></td></tr>");
	    
	        $("input[name='name']").val('');
	        $("input[name='email']").val('');
	        $("input[name='userid']").val('');
	        $("input[name='doj']").val('');
	        $("select").val('');
	        $("input[name='sq']").val('');	
	        $(".data-visible").hide();
			}
		else if(saveOrUpdate=="update")
			{
			e.preventDefault();
			   var name = $("input[name='name']").val();
	           var email = $("input[name='email']").val();
	           var userid = $("input[name='userid']").val();
	             var sq = $("input[name='sq']").val();
	             var doj=new Date($("input[name='doj']").val()); 
	             var day = ("0" + doj.getDate()).slice(-2);
	         	let formatted_date =day + "-" + months[doj.getMonth()] + "-" + doj.getFullYear();

	 	        var role=$("select").val(); 
	             $.each($userObjects, function(i, user) {
	         		if(user.userId==userid)
	         			{
	         			user.userName=name;
	         			user.email=email;
	         			user.userId=userid;
	         			user.doj=formatted_date;
	         			user.role=role;
	         			user.updated=true;
	         			}
	         	});
	           $(".data-table tbody").find("tr:eq("+sq+")").replaceWith("<tr data-sq='"+sq+"' data-name='"+name+"' data-email='"+email+"' data-userid='"+userid+"' data-doj='"+formatted_date+"' data-role='"+role+"'><td class='data-visible'>"+sq+"</td><td>"+userid+"</td><td>"+name+"</td><td>"+email+"</td><td>"+formatted_date+"</td><td>"+role+"</td><td><button class='btn btn-info btn-xs btn-edit'>Edit</button><button class='btn btn-danger btn-xs btn-delete'>Delete</button></td></tr>");
	           $("input[name='name']").val('');
		        $("input[name='email']").val('');
		        $("input[name='userid']").val('');
		        $("input[name='doj']").val('');
		        $("select").val('');
		        $("input[name='sq']").val('');	
		        $("input[name='userid']").prop('disabled', false);
	           $(".save-btn").attr("value","add");
			   $(".save-btn").text("Add");
			   $(".data-visible").hide();
			}
		  
	});
	   
   
   
    $("body").on("click", ".btn-delete", function(){
    	var userid = $(this).parents("tr").attr('data-userid');
    	$.each($userObjects, function(i, user) {
    		if(user.userId==userid)
    			{
    			user.active=false;
    			user.updated=true;
    			}
    	});
        $(this).parents("tr").remove();
        
        $("input[name='name']").val('');
        $("input[name='email']").val('');
        $("input[name='userid']").val('');
        $("input[name='doj']").val('');
        $("select").val('');
        $("input[name='sq']").val('');	
        $(".save-btn").attr("value","add");
		   $(".save-btn").text("Add");
    });
    
    $("body").on("click", ".btn-edit", function(){
        var name = $(this).parents("tr").attr('data-name');
        var email = $(this).parents("tr").attr('data-email');
        var userid = $(this).parents("tr").attr('data-userid');
        var role = $(this).parents("tr").attr('data-role');
        var doj = new Date($(this).parents("tr").attr('data-doj'));
        var sq = $(this).parents("tr").index();
        
        $("input[name='name']").val(name);
        $("input[name='email']").val(email);
        $("input[name='userid']").val(userid);
        var now = new Date(doj);

        var day = ("0" + now.getDate()).slice(-2);
        var month = ("0" + (now.getMonth() + 1)).slice(-2);

        var formateddoj = now.getFullYear()+"-"+(month)+"-"+(day) ;
        $("input[name='doj']").val(formateddoj);
        $("select").val(role);
        $("input[name='sq']").val(sq);
        $("input[name='userid']").prop('disabled', true);
        $(".save-btn").attr("value","update");
		$(".save-btn").text("Update");
    });
   

		$("body").on("click", "#saveusers", function() {
						/* $.each($userObjects, function(i, user) {
							
								alert("username: "+user.userName+"user Id: "+user.userId+"updated: "+user.updated);
								
						});*/
						//send data to backend
						$.ajax({
							url : '/rest/user/saveAllUsers',
							type : 'post',
							dataType : 'text',
							contentType : 'application/json',
							success : function() {
								$("#myModal").modal();
								
							},
							error : function(request, status, error) {
								alert(status + "," + error);
							},
							data : JSON.stringify($userObjects)

						});
			});
   
   $(".closempdel").click(function(){
	   $('#myModal').modal('hide'); 
   });
    

});