/**
 * 
 */

$(document).ready(function() {
	
	//load all modules dynamically  
	/*var $myList = $("#moduleList");
	var newItems = [];
	//ajax call for loading all modules
	$.getJSON("http://localhost:9090/course/getAllModules", function(result) {
		$.each(result, function(i, obj) {
			newItems.push("<a href='#' class='module'>" + obj + "</a>");
		});
		// Append the new items to your list
		$myList.append(newItems.join(""));
	
	});*/
	var level=1;
	$(document).on("click", ".module", function() {
		
		var moduleName = $(this).attr("id");
		$(".dynamicTopics").remove();
		var $topicList = $("#bodycontent");
		var newItems = [];
		//ajax call for loading all  allTopicsByModule
		var url = "http://localhost:9090/course/allTestTpoics/" + moduleName;
		$.getJSON(url, function(result) {
			$.each(result, function(i, obj) {
				var moduleDiv="<div class='panel-group dynamicTopics'><div class='panel panel-default'><div class='panel-heading'><h4 class='  panel-title'><a class='accordion-toggle' data-toggle='collapse' href='#replacecollapse'>topcName</a></h4></div><div id='replacecollapse' class='panel-collapse collapse '><ul class='list-group topicDetailClass'>topicDetails</ul></div></div></div>";
				var topicUrl="<li class='list-group-item'> <ul class='list-inline'><li>Synopsis</li><li style='float:right'><a href='iframedoc.html?fileName="+obj.sourceLocation+"' class='btn btn-primary'>Open</a></li></ul></li>";
				var testUrl="<li class='list-group-item'> <ul class='list-inline'><li>Test</li><li style='float:right'><a href='testPaper.html?moduleName="+obj.moduleName+"&topicName="+obj.topicName+"&courseId="+obj.courseId+"'class='btn btn-primary'>Open</a></li></ul></li>";
				var levebox="<span style='padding-left:5px'><label for='level'>Level:</label><select id='level'><option value='1'>1</option> <option value='2'>2</option> <option value='3'>3</option> <option value='4'>4</option>'</select></span>";
				if(obj.attemptedTimes>0)
					{
					var badge="<label  class='btn btn-info' style='margin-right:10px'>Attempted <span class='badge badge-light'>"+obj.attemptedTimes+"</span></label>";
				    testUrl="<li class='list-group-item'> <ul class='list-inline'><li>Test</li><li style='float:right'>"+badge+levebox+"<a href='testPaper.html?moduleName="+obj.moduleName+"&topicName="+obj.topicName+"&courseId="+obj.courseId+"'  class='btn btn-primary testlink'>Open</a></li></ul></li>";
					}
				else
					{
					testUrl="<li class='list-group-item'> <ul class='list-inline'><li>Test</li><li style='float:right'>"+levebox+"<a href='testPaper.html?moduleName="+obj.moduleName+"&topicName="+obj.topicName+"&courseId="+obj.courseId+"'  class='btn btn-primary testlink'>Open</a></li></ul></li>";
					}
				moduleDiv=moduleDiv.replace(/replacecollapse/g, "collapse"+i);
				moduleDiv=moduleDiv.replace("topcName",obj.topicName);
				moduleDiv=moduleDiv.replace("topicDetails",topicUrl+testUrl);
				
				newItems.push(moduleDiv);
			});
			$topicList.append(newItems.join(""));
		});
		
		$(document).on("change", "#level", function() {
			level=$( "#level option:selected" ).text();
			var link=$(".testlink").attr("href");
			link=link+"&level="+$( "#level option:selected" ).text();
			$(".testlink").attr("href",link);
		});
		$(document).on("click", ".testlink", function() {
			var link=$(".testlink").attr("href");
			link=link+"&level="+level;
			$(".testlink").attr("href",link);
		});
		
	});

});