create table COURSE_SEQUENCE_KEY
(key_name varchar(50)not null primary key,
key_value int not null);

create table MODULES(
module_name varchar(20)  primary key);

create table COURSE
(
course_id varchar(20) primary key,
module_name varchar(20) not null,
topic_name varchar(50) not null,
course_type varchar(20) not null,
source_location varchar(50) not null,
Constraint fk_course_module_name FOREIGN KEY(module_name) REFERENCES MODULES(module_name));


create table PS_USER_ROLES(
role_id int primary key,
role_name varchar(30) not null);


create table PS_USER(
user_id int primary key,
user_name varchar(50) not null,
full_name varchar(60),
email_address varchar(60) not null,
doj date not null,
password varchar(30) not null,
role_id int,
available varchar(5),
Constraint fk_role_id FOREIGN KEY(role_id) REFERENCES PS_USER_ROLES(role_id)
);


create table EVALUATION
(
evaluation_id int primary key,
course_id varchar(20) not null,
user_id int not null,
evaluation_date date not null,
total_score int not null,
Constraint fk_course_evaluation_id FOREIGN KEY(course_id) REFERENCES COURSE(course_id),
Constraint fk_course_user_id FOREIGN KEY(user_id) REFERENCES PS_USER(user_id));

create table SCORE_CARD
(
scard_id int primary key,
evaluation_id int not null,
question_name varchar(1000),
options varchar(500),
correct_option varchar(200),
selected_answer varchar(200),
Constraint fk_evaluation_scard_id FOREIGN KEY(evaluation_id) REFERENCES EVALUATION(evaluation_id)
);