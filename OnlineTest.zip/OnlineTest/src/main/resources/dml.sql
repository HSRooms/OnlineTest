insert into MODULES values('customer');
insert into MODULES values('policy');
insert into MODULES values('claim');
insert into MODULES values('bill');
insert into MODULES values('case');

insert into COURSE(course_id,module_name,topic_name,source_location,course_type) values(1,'customer','Create Customer','EventActionHLD.pdf','functional');
insert into COURSE(course_id,module_name,topic_name,source_location,course_type) values(2,'policy','Create Policy','EventActionHLD (002).pdf','functional');
insert into COURSE(course_id,module_name,topic_name,source_location,course_type) values(3,'claim','Create Claim','EventActionHLD (002).pdf','functional');
insert into COURSE(course_id,module_name,topic_name,source_location,course_type) values(4,'case','Create Case','EventActionHLD (002).pdf','functional');
insert into COURSE(course_id,module_name,topic_name,source_location,course_type) values(5,'bill','Create Bill','EventActionHLD (002).pdf','functional');
insert into COURSE(course_id,module_name,topic_name,source_location,course_type) values(6,'customer','Update Customer','EventActionHLD.pdf','functional');


insert into ps_user_roles values(1001,'USER');
insert into ps_user_roles values(1002,'ADMIN');

insert into ps_user values('2001','User',null,'user@sapiens.com', TO_TIMESTAMP('2019-01-01','YYYY-MM-DD'),'password123',1001,'y');
insert into ps_user values(2002,'Harshavardhana.S',null,'Harshavardhana.S@sapiens.com',TO_TIMESTAMP('2019-01-01','YYYY-MM-DD'),'admin123',1001,'y');
insert into ps_user values(2003,'Benudhor Angom',null,'Benudhor.Angom@sapiens.com',TO_TIMESTAMP('2019-01-01','YYYY-MM-DD'),'admin123',1002,'y');
insert into ps_user values(2004,'Akash',null,'Akash.hanchinal@sapiens.com',TO_TIMESTAMP('2019-01-01','YYYY-MM-DD'),'admin123',1001,'y');
insert into ps_user values(2005,'SarathBabu J',null,'SarathBabu.J@sapiens.com',TO_TIMESTAMP('2019-01-01','YYYY-MM-DD'),'admin123',1001,'y');
insert into ps_user values(2006,'Santosh Choudary',null,'santosh.c@sapiens.com',TO_TIMESTAMP('2019-01-01','YYYY-MM-DD'),'admin123',1001,'y');
insert into COURSE_SEQUENCE_KEY values('evaluationEntity',1);
insert into COURSE_SEQUENCE_KEY values('scoreCardEntity',1);


