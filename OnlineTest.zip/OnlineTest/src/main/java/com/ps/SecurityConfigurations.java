package com.ps;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.ps.auth.service.AuthService;
import com.ps.auth.service.RoleBasedAuthenticationSuccessHandler;

@Configuration
@EnableWebSecurity
@AutoConfigureOrder(Ordered.LOWEST_PRECEDENCE)
public class SecurityConfigurations extends WebSecurityConfigurerAdapter {

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		PasswordEncoder encoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();
		authService.buildAuth(auth, encoder);
		/*
		 * auth .inMemoryAuthentication()
		 * .withUser("test").password(encoder.encode("password")).roles("USER");
		 */
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.headers().frameOptions().disable();
		http.csrf().disable().authorizeRequests()
				// .antMatchers("/admin/**").hasRole("ADMIN")
				// .antMatchers("/anonymous*").anonymous()
				.antMatchers(new String[]{"/rest/*","/login*","/js/*","/css/*","/bootstrap-3.4.1/*"}).permitAll()
				.antMatchers(new String[]{"/admin","/admin*","/user_performance*"}).access("hasRole('ROLE_ADMIN')")
				.antMatchers(new String[]{"/user","/home*"}).access("hasRole('ROLE_USER')").anyRequest().authenticated().and().formLogin()
				.loginPage("/login").successHandler(roleBasedAuthenticationSuccessHandler).failureUrl("/login?error=true").and().logout().logoutUrl("/logout.jsp")
				.deleteCookies("JSESSIONID").and().exceptionHandling().accessDeniedPage("/accessDenied.jsp");
	}

	@Autowired
	private AuthService authService;
	@Autowired
    public RoleBasedAuthenticationSuccessHandler roleBasedAuthenticationSuccessHandler; 
}
