package com.ps.course.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ps.course.service.CourseService;
import com.ps.dto.CourseDTO;

@RestController
@RequestMapping("/course")
public class CourseController {
	
	@Autowired
	private CourseService CourseService;

	@RequestMapping(value="/allTestTpoics/{module}")
	public List<CourseDTO> getAllTopics(@PathVariable("module") String module)
	{
	  return CourseService.retrieveTopicsByModule(module);
	}
	@RequestMapping("/getAllModules")
	public List<String> getAllModules()
	{
		return CourseService.retrieveAllModules();
	}
	
	@RequestMapping("/retrieveCourse/{courseId}")
	public CourseDTO retrieveCourseById(@PathVariable("courseId") String courseId)
	{
		return CourseService.retrieveCourseById(courseId);
	}
	
	
}
