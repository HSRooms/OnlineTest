package com.ps.course.service;

import java.util.List;

import com.ps.dto.CourseDTO;
import com.ps.dto.TestQuestionsDTO;

public interface CourseService {
  List<String> retrieveAllModules();
  List<CourseDTO> retrieveTopicsByModule(String moduleName);
  List<TestQuestionsDTO> retrieveQuestionsByTopic(String moduleName,String topicName,String courseId,int level);
  CourseDTO retrieveCourseById(String courseId);
}
