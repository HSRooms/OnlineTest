package com.ps.course.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.ps.course.jpa.CourseEntity;
import com.ps.course.jpa.CourseRepository;
import com.ps.dto.CourseDTO;
import com.ps.dto.TestQuestionsDTO;
import com.ps.evaluation.jpa.EvaluationRepository;
import com.ps.helper.TestExcelReader;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private CourseRepository courseRepository;
	
	@Autowired
	private TestExcelReader testExcelReader;
	
	@Autowired
	private EvaluationRepository evaluationRepository;
    
	private static String RETRIVE_ALL_MODULES="select module_name  from modules";
	@Override
	public List<String> retrieveAllModules() {
		// TODO Auto-generated method stub
		return jdbcTemplate.queryForList(RETRIVE_ALL_MODULES, String.class);
	}
	@Override
	public List<CourseDTO> retrieveTopicsByModule(String moduleName) {
		// TODO Auto-generated method stub
		List<CourseDTO> list=convertCourseEntitysToCourseDTOs(courseRepository.loadTopicsByModule(moduleName));
		return list;
	}
 
	private CourseDTO convertCourseEntityToCourseDTO(CourseEntity entity)
	{
		CourseDTO dto=new CourseDTO();
		dto.setCourseId(entity.getCourse_id());
		dto.setModuleName(entity.getModule_name());
		dto.setSourceLocation(entity.getSource_location());
		dto.setTopicName(entity.getTopic_name());
		dto.setCourseType(entity.getCourse_type());
		return dto;
	}
	
	private List<CourseDTO> convertCourseEntitysToCourseDTOs(List<CourseEntity> entities)
	{
	    List<CourseDTO> list=new ArrayList<>();
	    for(CourseEntity entity:entities)
	    {
		CourseDTO dto=new CourseDTO();
		dto.setCourseId(entity.getCourse_id());
		dto.setModuleName(entity.getModule_name());
		dto.setSourceLocation(entity.getSource_location());
		dto.setTopicName(entity.getTopic_name());
		dto.setCourseType(entity.getCourse_type());
		dto.setAttemptedTimes(evaluationRepository.attemptsCount(entity.getCourse_id(), getUserId()));
		list.add(dto);
	    }
		return list;
	}
	@Override
	public List<TestQuestionsDTO> retrieveQuestionsByTopic(String moduleName, String topicName,String courseId,int level) {
		// TODO Auto-generated method stub
		return testExcelReader.readTopicData(moduleName, topicName,courseId,level);
	}
	private String getUserId()
	{
		String username=null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			 username = ((UserDetails) principal).getUsername();
		} else {
			 username = principal.toString();
		}
		return username;
	}
	@Override
	public CourseDTO retrieveCourseById(String courseId) {
		// TODO Auto-generated method stub
		Optional<CourseEntity> courseDTO=courseRepository.findById(courseId);
		return courseDTO.isPresent()?convertCourseEntityToCourseDTO(courseDTO.get()):null;
	}
	
}
