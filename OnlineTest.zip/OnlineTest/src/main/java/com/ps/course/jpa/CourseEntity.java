package com.ps.course.jpa;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;



@Entity
@Table(name="Course")
@Component
@Scope(value="prototype")
@NamedQueries({
	@NamedQuery(name=CourseEntity.QN_topicsByModule,query="select c from CourseEntity c where c.module_name=?1 order by c.course_id")})
public class CourseEntity {
	public static String COMPONENT_NAME="courseEntity";
	public static final String QN_topicsByModule = "CourseEntity.loadTopicsByModule";
	
	@Id
	private String course_id;
	private String module_name;
	private String topic_name ;
	private String source_location;
	private String course_type;
	public String getModule_name() {
		return module_name;
	}
	public void setModule_name(String module_name) {
		this.module_name = module_name;
	}
	public String getTopic_name() {
		return topic_name;
	}
	public void setTopic_name(String topic_name) {
		this.topic_name = topic_name;
	}
	public String getSource_location() {
		return source_location;
	}
	public void setSource_location(String source_location) {
		this.source_location = source_location;
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public String getCourse_type() {
		return course_type;
	}
	public void setCourse_type(String course_type) {
		this.course_type = course_type;
	}
}
