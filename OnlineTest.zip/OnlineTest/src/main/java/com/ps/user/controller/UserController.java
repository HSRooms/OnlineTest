package com.ps.user.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ps.dto.UserDTO;
import com.ps.user.service.UserService;

@RestController
@RequestMapping("/rest/user")
public class UserController {
	
	@Autowired
	private UserService userService;

	@RequestMapping(value="/addUser",method=RequestMethod.POST,consumes="application/json")
	public void saveUser(@RequestBody UserDTO userDTO)
	{
		userService.addUser(userDTO);	
	}
	
	@RequestMapping(value="/updateUser",method=RequestMethod.PUT,consumes="application/json")
	public void updateUser(@RequestBody UserDTO userDTO)
	{
		userService.updateUser(userDTO);	
	}
	
	@RequestMapping(value="/deleteUser/{userId}",method=RequestMethod.GET)
	public UserDTO deleteUser(@PathVariable("userId") String userId)
	{
		return userService.deleteUser(userId);	
	}
	
	@RequestMapping(value="/retrieveAllUsers",method=RequestMethod.GET)
	public List<UserDTO> retrieveAll()
	{
		return userService.retrieveAllUsers();	
	}
	
	@RequestMapping(value="/saveAllUsers",method=RequestMethod.POST,consumes="application/json")
	public void saveAllUsers(@RequestBody List<UserDTO> userDTOs)
	{
		userService.saveAllUsers(userDTOs);	
	}
}
