package com.ps.user.service;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ps.auth.jpa.PSUserEntity;
import com.ps.auth.jpa.PSUserRepository;
import com.ps.dto.UserDTO;
import com.ps.util.MapperUtility;
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private PSUserRepository psUserRepository;
	
	@Autowired
	private MapperUtility utility;
	
	@Override
	public void addUser(UserDTO user) {
		// TODO Auto-generated method stub
		try {
			psUserRepository.save(utility.convertUserDtoToEntity(user));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid user");
		}
	}

	@Override
	public UserDTO updateUser(UserDTO user) {
		// TODO Auto-generated method stub
		try {
			 psUserRepository.save(utility.convertUserDtoToEntity(user));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid user");
		}
		return user;
	}

	@Override
	public UserDTO deleteUser(String userId) {
		// TODO Auto-generated method stub
		Optional<PSUserEntity> entity=psUserRepository.findById(userId);
		if(entity.isPresent())
		{
			psUserRepository.delete(entity.get());
			return utility.convertUserEntityToDto(entity.get());
		}
		else
		{
			return null;
		}
	}

	@Override
	public List<UserDTO> retrieveAllUsers() {
		// TODO Auto-generated method stub
		return utility.convertUserEntitysToDtos(psUserRepository.findAllActiveUsers());
	}

	@Override
	public void saveAllUsers(List<UserDTO> users) {
		// TODO Auto-generated method stub
		try {
			psUserRepository.saveAll(utility.convertUserDtosToEntitys(users.stream().filter(user->user.isUpdated()).collect(Collectors.toList())));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			System.out.println("Invalid users");
		}
	}

}
