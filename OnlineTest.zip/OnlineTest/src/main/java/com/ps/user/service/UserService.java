package com.ps.user.service;

import java.util.List;

import com.ps.dto.UserDTO;

public interface UserService {
	void addUser(UserDTO user);
    UserDTO updateUser(UserDTO user);
    UserDTO deleteUser(String userId);
    void saveAllUsers(List<UserDTO> users);
    List<UserDTO> retrieveAllUsers();
}
