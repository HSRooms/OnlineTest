package com.ps.auth.service;

import java.util.List;

import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.ps.auth.jpa.PSUserEntity;

public interface AuthService {
	
	public List<PSUserEntity> retrieveAllUsersAndRoles();

	public AuthenticationManagerBuilder buildAuth(AuthenticationManagerBuilder auth, PasswordEncoder encoder) throws Exception ;

}
