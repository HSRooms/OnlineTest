package com.ps.auth.jpa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name="ps_user_roles")
@Component
@Scope(value="prototype")
public class PSUserRolesEntity
{
	public static String COMPONENT_NAME="ps_user_roles";

	@Id
	@Column(name = "role_id")
	private int userRoleId;
	
	@Column(name = "role_name")
	private String roleName;

	public int getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
}
