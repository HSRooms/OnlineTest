package com.ps.auth.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PSUserRepository extends JpaRepository<PSUserEntity, String>{
	
	public List<PSUserEntity> findAllActiveUsers();

}
