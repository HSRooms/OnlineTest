package com.ps.auth.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ps.auth.jpa.PSUserEntity;
import com.ps.auth.jpa.PSUserRepository;
import com.ps.auth.jpa.PSUserRolesRepository;
import com.ps.dto.UserDTO;


@Component
public class AuthServiceImpl implements AuthService {
	
	
	
	@Autowired
	private PSUserRepository psUserRepository;
	
	@Autowired
	private PSUserRolesRepository psUserRolesRepository;
	
	
	@Override
	public List<PSUserEntity> retrieveAllUsersAndRoles()
	{
		
		List<PSUserEntity> userEntityList = psUserRepository.findAllActiveUsers();
		return userEntityList;
	}

	@Override
	public AuthenticationManagerBuilder buildAuth(AuthenticationManagerBuilder auth, PasswordEncoder encoder) throws Exception {
		
		int count = 0;
		List<PSUserEntity> users = retrieveAllUsersAndRoles();
		if(users != null && users.size()>0)
		{
			for(PSUserEntity user :users)
			{
				count++;
				auth
				.inMemoryAuthentication()
				.withUser(user.getUserId()).password(encoder.encode(user.getPassword())).roles(psUserRolesRepository.findById(user.getRoleId()).get().getRoleName());
				//.withUser(user.getUserName()).password("{noop}"+user.getPassword()).roles(psUserRolesRepository.findById(user.getRoleId()).get().getRoleName());
			}
		}
		return auth;
		/*auth
		.inMemoryAuthentication()
			.withUser("user").password("{noop}password123").roles("USER");
		*/
		
		
	}
	
	@RequestMapping(value="/logout", method = RequestMethod.GET)
	public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
	    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	    if (auth != null){
	        new SecurityContextLogoutHandler().logout(request, response, auth);
	    }
	    return "redirect:/login";//You can redirect wherever you want, but generally it's a good practice to show login screen again.
	}
 
}
