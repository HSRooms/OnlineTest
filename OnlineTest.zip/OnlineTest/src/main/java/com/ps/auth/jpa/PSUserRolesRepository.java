package com.ps.auth.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PSUserRolesRepository extends JpaRepository<PSUserRolesEntity, Integer>{

}
