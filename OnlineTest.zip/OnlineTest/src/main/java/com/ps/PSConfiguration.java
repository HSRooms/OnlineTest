package com.ps;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureOrder;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;

@Configuration
@PropertySources({
	@PropertySource(value = "classpath:/application.properties", ignoreResourceNotFound = true),
})
@AutoConfigureOrder(Ordered.HIGHEST_PRECEDENCE)
public class PSConfiguration {

	@Autowired
	public ApplicationContext applicationContext;
	
    @Autowired
	private Environment env;
	@Bean
    public DataSource getDataSource() {
		
		DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
        dataSourceBuilder.driverClassName("oracle.jdbc.driver.OracleDriver");
        dataSourceBuilder.url("jdbc:oracle:thin:@localhost:1522:PSUITE19");
        dataSourceBuilder.username("pcmp");
        dataSourceBuilder.password("XXXXX");
        
        return dataSourceBuilder.build();
    }
	
}
