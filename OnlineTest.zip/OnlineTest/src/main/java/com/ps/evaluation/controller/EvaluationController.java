package com.ps.evaluation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ps.course.service.CourseService;
import com.ps.dto.TestQuestionsDTO;
import com.ps.evaluation.service.EvaluationService;

@RestController
@RequestMapping("/evaluation")
public class EvaluationController {
	@Autowired
	private CourseService courseService;
	@Autowired
	private EvaluationService evaluationService;
	
	@RequestMapping("/retrieveQuestionsByTopic")
	public List<TestQuestionsDTO> retrieveQuestionsByTopic(@RequestParam("moduleName") String moduleName,@RequestParam("topicName") String topicName,@RequestParam("courseId") String courseId,@RequestParam("level") int level)
	{
		return courseService.retrieveQuestionsByTopic(moduleName, topicName,courseId,level);
	}
	@RequestMapping(value="/submitTest",method=RequestMethod.POST,consumes="application/json",produces="text/plain")
	public String submitTest(@RequestBody List<TestQuestionsDTO> testQuestions)
	{
		if(testQuestions.size()>0)
		{
			evaluationService.evaluateTest(testQuestions);
			return "Success";
		}
		else
		{
			return "Failed";
		}
	}
}
