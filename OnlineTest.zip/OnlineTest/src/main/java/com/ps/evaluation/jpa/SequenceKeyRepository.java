package com.ps.evaluation.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SequenceKeyRepository extends JpaRepository<SequenceKey, String>{

}
