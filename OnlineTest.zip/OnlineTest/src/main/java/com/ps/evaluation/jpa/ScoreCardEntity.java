package com.ps.evaluation.jpa;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name="SCORE_CARD")
@Component
@Scope(value="prototype")
public class ScoreCardEntity {

	public static String COMPONENT_NAME="scoreCardEntity";
	
	@Id
	private int scard_id;
	
	private int evaluation_id;
	private String question_name;
	private String options;
	private String correct_option;
	private String selected_answer;
	public String getSelected_answer() {
		return selected_answer;
	}
	public void setSelected_answer(String selected_answer) {
		this.selected_answer = selected_answer;
	}
	public int getScard_id() {
		return scard_id;
	}
	public void setScard_id(int scard_id) {
		this.scard_id = scard_id;
	}
	public int getEvaluation_id() {
		return evaluation_id;
	}
	public void setEvaluation_id(int evaluation_id) {
		this.evaluation_id = evaluation_id;
	}
	
	public String getQuestion_name() {
		return question_name;
	}
	public void setQuestion_name(String question_name) {
		this.question_name = question_name;
	}
	public String getOptions() {
		return options;
	}
	public void setOptions(String options) {
		this.options = options;
	}
	public String getCorrect_option() {
		return correct_option;
	}
	public void setCorrect_option(String correct_option) {
		this.correct_option = correct_option;
	}
	
	
}
