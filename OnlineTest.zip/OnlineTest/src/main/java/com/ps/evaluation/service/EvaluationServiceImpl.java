package com.ps.evaluation.service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.ps.dto.EvaluationDTO;
import com.ps.dto.TestQuestionsDTO;
import com.ps.evaluation.jpa.EvaluationEntity;
import com.ps.evaluation.jpa.EvaluationRepository;
import com.ps.evaluation.jpa.ScoreCardEntity;
import com.ps.util.MapperUtility;
import com.ps.util.SequenceKeyUtil;

@Service
public class EvaluationServiceImpl implements EvaluationService {

	@Autowired
	private ApplicationContext applicationContext;
	@Autowired
	private SequenceKeyUtil sequenceKeyUtil;
	@Autowired
	private EvaluationRepository evaluationRepository;

	@Autowired
	private CacheManager ehCacheCacheManager;
	
	@Autowired
	private MapperUtility utility;

	@Override
	@Transactional
	public EvaluationEntity evaluateTest(List<TestQuestionsDTO> testDtos) {
		// TODO Auto-generated method stub
		String courseId = null;
		int level=0;
		if (testDtos.size() > 0) {
			courseId = testDtos.get(0).getCourseId();
			level=testDtos.get(0).getLevel();
		} else {
			return null;
		}

		String username=null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			 username = ((UserDetails) principal).getUsername();
		} else {
			 username = principal.toString();
		}
		EvaluationEntity evaluationEntity = applicationContext.getBean(EvaluationEntity.class);
		evaluationEntity.setCourse_id(courseId);
		evaluationEntity.setUser_id(username);
		evaluationEntity.setEvaluation_date(Calendar.getInstance().getTime());
		evaluationEntity.setTest_level(level);
		evaluationEntity
				.setEvaluation_id(Integer.parseInt(sequenceKeyUtil.getSequenceValue(EvaluationEntity.COMPONENT_NAME)));
		prepareScoreCard(evaluationEntity, testDtos);
		evaluationEntity = evaluationRepository.saveAndFlush(evaluationEntity);
		return evaluationEntity;
	}

	private void prepareScoreCard(EvaluationEntity evaluationEntity, List<TestQuestionsDTO> testDtos) {
		int score = 0;
		List<ScoreCardEntity> scoreCardEntitys = new ArrayList<ScoreCardEntity>();
		Cache cache = ehCacheCacheManager.getCache("pscache");
		Map<String, String> answerMap = cache.get("answerMap", Map.class);
		for (TestQuestionsDTO testDto : testDtos) {
			ScoreCardEntity scoreCardEntity = applicationContext.getBean(ScoreCardEntity.class);
			scoreCardEntity.setQuestion_name(testDto.getQuestionsName());
			scoreCardEntity
					.setScard_id(Integer.parseInt(sequenceKeyUtil.getSequenceValue(ScoreCardEntity.COMPONENT_NAME)));
			scoreCardEntity.setEvaluation_id(evaluationEntity.getEvaluation_id());
			scoreCardEntity.setCorrect_option(answerMap.get(testDto.getQuestionsName().trim()));
			scoreCardEntity.setOptions(getOptionsString(testDto.getOptions()));
			scoreCardEntity.setSelected_answer(testDto.getSelectedAnswer());
			if (scoreCardEntity.getCorrect_option().equalsIgnoreCase(testDto.getSelectedAnswer())) {
				score++;
			}
			scoreCardEntitys.add(scoreCardEntity);
		}
		evaluationEntity.setTotal_score(score);
		evaluationEntity.setScoreCardEntitys(scoreCardEntitys);
	}

	private String getOptionsString(List<String> options) {
		StringBuffer optionString = new StringBuffer();
		for (String val : options) {
			optionString.append(val + ",");
		}
		String result = optionString.toString();
		return result.substring(0, result.length());
	}

	@Override
	public List<EvaluationDTO> retrieveByUserId(String userId) {
		// TODO Auto-generated method stub
		return utility.convertEvaluationEntitysToDtos(evaluationRepository.retrieveByUserId(userId));
	}
}
