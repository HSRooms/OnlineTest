package com.ps.evaluation.jpa;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EvaluationRepository extends JpaRepository<EvaluationEntity, Integer>{

	public int attemptsCount(String courseId,String userId);
	public List<EvaluationEntity> retrieveByUserId(String userId);
}
