package com.ps.evaluation.jpa;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ScoreCardRepository extends JpaRepository<ScoreCardEntity, Integer> {

}
