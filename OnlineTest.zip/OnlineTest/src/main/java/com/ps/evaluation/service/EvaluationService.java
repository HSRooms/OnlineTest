package com.ps.evaluation.service;

import java.util.List;

import com.ps.dto.EvaluationDTO;
import com.ps.dto.TestQuestionsDTO;
import com.ps.evaluation.jpa.EvaluationEntity;

public interface EvaluationService {

	EvaluationEntity evaluateTest(List<TestQuestionsDTO> testDtos);
	List<EvaluationDTO> retrieveByUserId(String userId);
}
