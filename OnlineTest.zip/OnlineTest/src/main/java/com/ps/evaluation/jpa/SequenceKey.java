package com.ps.evaluation.jpa;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Entity
@Table(name="COURSE_SEQUENCE_KEY")
@Component
@Scope(value="prototype")
public class SequenceKey {
	@Id
	private String key_name;
	private int key_value;

	public String getKey_name() {
		return key_name;
	}
	public void setKey_name(String key_name) {
		this.key_name = key_name;
	}
	public int getKey_value() {
		return key_value;
	}
	public void setKey_value(int key_value) {
		this.key_value = key_value;
	}
	
}
