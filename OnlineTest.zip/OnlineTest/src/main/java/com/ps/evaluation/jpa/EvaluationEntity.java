package com.ps.evaluation.jpa;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.ps.course.jpa.CourseEntity;

@Entity
@Table(name="EVALUATION")
@Component
@Scope(value="prototype")
@NamedQueries({
	@NamedQuery(name=EvaluationEntity.QN_Attempted_Count,query="select count(*) from EvaluationEntity where course_id=?1 and user_id=?2"),
	@NamedQuery(name=EvaluationEntity.QN_RetrieveBy_UserId,query="select e from EvaluationEntity e where e.user_id=?1 order by e.course_id")})

public class EvaluationEntity {

	public static String COMPONENT_NAME="evaluationEntity";

	public static final String QN_Attempted_Count="EvaluationEntity.attemptsCount";
	public static final String QN_RetrieveBy_UserId="EvaluationEntity.retrieveByUserId"; 
	@Id
	private int evaluation_id;
	private String course_id;
	private String user_id;
	private Date evaluation_date;
	private int test_level;
	private int total_score;
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name="evaluation_id")
	private List<ScoreCardEntity> scoreCardEntitys;
	
	public int getEvaluation_id() {
		return evaluation_id;
	}
	public void setEvaluation_id(int evaluation_id) {
		this.evaluation_id = evaluation_id;
	}
	public String getCourse_id() {
		return course_id;
	}
	public void setCourse_id(String course_id) {
		this.course_id = course_id;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public Date getEvaluation_date() {
		return evaluation_date;
	}
	public void setEvaluation_date(Date evaluation_date) {
		this.evaluation_date = evaluation_date;
	}
	public int getTotal_score() {
		return total_score;
	}
	public void setTotal_score(int total_score) {
		this.total_score = total_score;
	}
	public List<ScoreCardEntity> getScoreCardEntitys() {
		return scoreCardEntitys;
	}
	public void setScoreCardEntitys(List<ScoreCardEntity> scoreCardEntitys) {
		this.scoreCardEntitys = scoreCardEntitys;
	}
	public int getTest_level() {
		return test_level;
	}
	public void setTest_level(int test_level) {
		this.test_level = test_level;
	}
	
	
	
}
