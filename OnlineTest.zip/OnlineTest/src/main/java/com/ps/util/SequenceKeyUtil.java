package com.ps.util;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ps.evaluation.jpa.EvaluationEntity;
import com.ps.evaluation.jpa.ScoreCardEntity;
import com.ps.evaluation.jpa.SequenceKey;
import com.ps.evaluation.jpa.SequenceKeyRepository;


@Component
public class SequenceKeyUtil {



	@Autowired
	private SequenceKeyRepository sequenceKeyRepository;
	
	public static final int incrementStategy=1;
	
	public  String getSequenceValue(String tableName)
	{
		String sequence=null;
		Optional<SequenceKey> optionalSequenceKey=sequenceKeyRepository.findById(tableName);
		if(optionalSequenceKey.isPresent())
		{
			SequenceKey sequenceKey=optionalSequenceKey.get();
			sequenceKey.setKey_value(sequenceKey.getKey_value()+incrementStategy);
			sequenceKeyRepository.save(sequenceKey);
			sequence=getStartWith().get(sequenceKey.getKey_name())+sequenceKey.getKey_value();
		}
		if(sequence==null||sequence.isEmpty())
		{
			//Need to convert CustomException
			try {
				throw new Exception();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return sequence;
	}
	
	public static  Map<String,String> getStartWith()
	{
		
		Map<String,String> namesMap=new HashMap<>();
		namesMap.put(EvaluationEntity.COMPONENT_NAME,"" );
		namesMap.put(ScoreCardEntity.COMPONENT_NAME,"" );
		return namesMap;
	}

}
