package com.ps.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import com.ps.auth.jpa.PSUserEntity;
import com.ps.dto.EvaluationDTO;
import com.ps.dto.ScoreCardDTO;
import com.ps.dto.UserDTO;
import com.ps.evaluation.jpa.EvaluationEntity;
import com.ps.evaluation.jpa.ScoreCardEntity;

@Component
public class MapperUtility {

	@Autowired
	private  ApplicationContext applicationContext;

	public  List<UserDTO> convertUserEntitysToDtos(List<PSUserEntity> entities) {
		List<UserDTO> dtos = new ArrayList<UserDTO>();
		for (PSUserEntity entity : entities) {
			UserDTO dto = new UserDTO();
			SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
			String date = sdf.format(entity.getDoj());
			dto.setDoj(date);
			dto.setEmail(entity.getEmailAddress());
			dto.setUserName(entity.getUserName());
			dto.setUserId(entity.getUserId());
			dto.setRole(entity.getRoleId());
			dto.setUserPw(entity.getPassword());
			dto.setActive(entity.getAvailable().equals("y")?true:false);
			dtos.add(dto);
		}
		return dtos;
	}

	public  UserDTO convertUserEntityToDto(PSUserEntity entity) {

		UserDTO dto = new UserDTO();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		String date = sdf.format(entity.getDoj());
		dto.setDoj(date);
		dto.setEmail(entity.getEmailAddress());
		dto.setUserName(entity.getUserName());
		dto.setUserId(entity.getUserId());
		dto.setUserPw(entity.getPassword());
		dto.setRole(entity.getRoleId());
		dto.setActive(entity.getAvailable().equals("y")?true:false);

		return dto;
	}

	public  PSUserEntity convertUserDtoToEntity(UserDTO dto) throws ParseException {

		PSUserEntity userEntity = applicationContext.getBean(PSUserEntity.class);
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");

		userEntity.setDoj(sdf.parse(dto.getDoj()));
		userEntity.setEmailAddress(dto.getEmail());
		userEntity.setUserName(dto.getUserName());
		userEntity.setUserId(dto.getUserId());
		userEntity.setPassword(dto.getUserPw());
		userEntity.setRoleId(dto.getRole());
		userEntity.setAvailable(dto.isActive()?"y":"n");
		return userEntity;
	}

	public  List<PSUserEntity> convertUserDtosToEntitys(List<UserDTO> dtos) throws ParseException {
        List<PSUserEntity> entities=new ArrayList<PSUserEntity>();
        for(UserDTO dto:dtos)
        {
        	PSUserEntity userEntity = applicationContext.getBean(PSUserEntity.class);
    		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");

    		userEntity.setDoj(sdf.parse(dto.getDoj()));
    		userEntity.setEmailAddress(dto.getEmail());
    		userEntity.setUserName(dto.getUserName());
    		userEntity.setUserId(dto.getUserId());
    		userEntity.setPassword(dto.getUserPw());
    		userEntity.setRoleId(dto.getRole());
    		userEntity.setAvailable(dto.isActive()?"y":"n");
    		entities.add(userEntity);
        }
		
		return entities;
	}
	public  List<EvaluationDTO> convertEvaluationEntitysToDtos(List<EvaluationEntity> entities) {
		List<EvaluationDTO> dtos = new ArrayList<EvaluationDTO>();
		for (EvaluationEntity entity : entities) {
			EvaluationDTO dto = new EvaluationDTO();
			dto.setCourseId(entity.getCourse_id());
			dto.setEvaluationDate(entity.getEvaluation_date());
			dto.setEvaluationId(entity.getEvaluation_id());
			dto.setTestLevel(entity.getTest_level());
			dto.setTotalScore(entity.getTotal_score());
			dto.setUserId(entity.getUser_id());
			List<ScoreCardEntity> scoreCardEntitys = entity.getScoreCardEntitys();
			List<ScoreCardDTO> sdtos = new ArrayList<>();
			for (ScoreCardEntity sentity : scoreCardEntitys) {
				ScoreCardDTO sdto = new ScoreCardDTO();
				sdto.setCorrectOption(sentity.getCorrect_option());
				sdto.setEvaluationId(sentity.getEvaluation_id());
				sdto.setOptions(sentity.getOptions());
				sdto.setQuestionName(sentity.getQuestion_name());
				sdto.setScardId(sentity.getScard_id());
				sdto.setSelectedAnswer(sentity.getSelected_answer());
				sdtos.add(sdto);
			}
			dto.setScoreCard(sdtos);
			dtos.add(dto);
		}
		return dtos;
	}
}
