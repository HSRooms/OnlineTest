package com.ps.dto;

import java.util.Date;
import java.util.List;

public class EvaluationDTO {

	private int evaluationId;
	private String courseId;
	private String userId;
	private Date evaluationDate;
	private int testLevel;
	private int totalScore;
	private List<ScoreCardDTO> scoreCard;
	public int getEvaluationId() {
		return evaluationId;
	}
	public void setEvaluationId(int evaluationId) {
		this.evaluationId = evaluationId;
	}
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getEvaluationDate() {
		return evaluationDate;
	}
	public void setEvaluationDate(Date evaluationDate) {
		this.evaluationDate = evaluationDate;
	}
	public int getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}
	public List<ScoreCardDTO> getScoreCard() {
		return scoreCard;
	}
	public void setScoreCard(List<ScoreCardDTO> scoreCard) {
		this.scoreCard = scoreCard;
	}
	public int getTestLevel() {
		return testLevel;
	}
	public void setTestLevel(int testLevel) {
		this.testLevel = testLevel;
	}
}
