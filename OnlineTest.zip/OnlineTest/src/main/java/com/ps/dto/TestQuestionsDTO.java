package com.ps.dto;

import java.util.List;

public class TestQuestionsDTO {
 
	private int questionNumber;
	private String questionsName;
	private String courseId;
	private int level;
	private String courseType;
	private List<String> options;
	private String selectedAnswer;
	public String getQuestionsName() {
		return questionsName;
	}
	public void setQuestionsName(String questionsName) {
		this.questionsName = questionsName;
	}
	
	public List<String> getOptions() {
		return options;
	}
	public void setOptions(List<String> options) {
		this.options = options;
	}
	public int getQuestionNumber() {
		return questionNumber;
	}
	public void setQuestionNumber(int questionNumber) {
		this.questionNumber = questionNumber;
	}
	public String getSelectedAnswer() {
		return selectedAnswer;
	}
	public void setSelectedAnswer(String selectedAnswer) {
		this.selectedAnswer = selectedAnswer;
	}
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getCourseType() {
		return courseType;
	}
	public void setCourseType(String courseType) {
		this.courseType = courseType;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
}
