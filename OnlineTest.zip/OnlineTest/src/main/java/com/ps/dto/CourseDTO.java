package com.ps.dto;

public class CourseDTO {

	private String courseId;
	private String moduleName;
	private String topicName ;
	private String sourceLocation;
	private String courseType;
	
	private int attemptedTimes;
	public String getCourseId() {
		return courseId;
	}
	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}
	public String getCourseType() {
		return courseType;
	}
	public void setCourseType(String courseType) {
		this.courseType = courseType;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public String getTopicName() {
		return topicName;
	}
	public void setTopicName(String topicName) {
		this.topicName = topicName;
	}
	public String getSourceLocation() {
		return sourceLocation;
	}
	public void setSourceLocation(String sourceLocation) {
		this.sourceLocation = sourceLocation;
	}
	public int getAttemptedTimes() {
		return attemptedTimes;
	}
	public void setAttemptedTimes(int attemptedTimes) {
		this.attemptedTimes = attemptedTimes;
	}
}
