package com.ps.helper;

import java.util.List;

import com.ps.dto.TestQuestionsDTO;

public interface TestExcelReader {

	List<TestQuestionsDTO> readTopicData(String moduleName,String topicName,String courseId,int level);
}
