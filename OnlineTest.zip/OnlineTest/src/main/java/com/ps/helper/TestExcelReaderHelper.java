package com.ps.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import com.ps.dto.TestQuestionsDTO;

@Component
public class TestExcelReaderHelper implements TestExcelReader {

	@Autowired
	private Environment env;
	
	@Autowired
	private CacheManager ehCacheCacheManager;

	@Override
	public List<TestQuestionsDTO> readTopicData(String moduleName, String topicName,String courseId,int level) {
		// TODO Auto-generated method stub
		List<TestQuestionsDTO> result = new ArrayList<>();
		Map<String,String> answersMap=new HashMap<>();
		Workbook workbook = loadWorkBook(env.getProperty(moduleName));
		if (workbook != null) {
			Sheet sheet = workbook.getSheet(topicName);
			if (sheet != null) {

				Iterator<Row> rows = sheet.iterator();
				int rowNum = 0;
				int questionNumber=0;
				while (rows.hasNext()) {
					if (rowNum == 0) {
						rowNum++;
						rows.next();
						continue;

					}
					TestQuestionsDTO testQuestionsDTO = new TestQuestionsDTO();
					List<String> options = new ArrayList<String>();
					Row row = rows.next();
					
					
					if (row.getCell(0) != null && row.getCell(6) != null) {
						int levelValue =(int)row.getCell(6).getNumericCellValue();
						if (levelValue == level) {
							testQuestionsDTO.setLevel(levelValue);
							testQuestionsDTO.setQuestionsName(row.getCell(0).getStringCellValue().trim());
							if (row.getCell(1) != null) {
								String value = row.getCell(1).getStringCellValue().trim();
								if (value != null && !value.trim().isEmpty()) {
									options.add(value);
								}

							}
							if (row.getCell(2) != null) {
								String value = row.getCell(2).getStringCellValue().trim();
								if (value != null && !value.trim().isEmpty()) {
									options.add(value);
								}

							}
							if (row.getCell(3) != null) {
								String value = row.getCell(3).getStringCellValue().trim();
								if (value != null && !value.trim().isEmpty()) {
									options.add(value);
								}

							}
							if (row.getCell(4) != null) {
								String value = row.getCell(4).getStringCellValue();
								if (value != null && !value.trim().isEmpty()) {
									options.add(value.trim());
								}

							}
							String correctAnser = row.getCell(5).getStringCellValue().trim();
							answersMap.put(testQuestionsDTO.getQuestionsName(), correctAnser);

							/*
							 * Iterator<Cell> cells = row.iterator(); int cellNum = 1; while
							 * (cells.hasNext()) { Cell cell = cells.next(); int type = cell.getCellType();
							 * if (type == 1) { switch (cellNum) { case 1:
							 * testQuestionsDTO.setQuestionsName(cell.getStringCellValue()); break; case 2:
							 * case 3: case 4: case 5: options.add(cell.getStringCellValue()); break; case
							 * 6: testQuestionsDTO.setCorrectAnswer(cell.getStringCellValue()); default:
							 * break; } }
							 * 
							 * cellNum++; }
							 */
							testQuestionsDTO.setOptions(options);
							testQuestionsDTO.setCourseId(courseId);
							testQuestionsDTO.setQuestionNumber(questionNumber);
							result.add(testQuestionsDTO);
							questionNumber++;
						}
						
					}
					rowNum++;
				}
			}
		}
		Cache cache=ehCacheCacheManager.getCache("pscache");
		cache.put("answerMap", answersMap);
		return result;
	}

	private static Workbook loadWorkBook(String locationName) {
		FileInputStream excelInputStream;
		Workbook workbook = null;
		try {
			excelInputStream = new FileInputStream(new File(locationName));
			workbook = new XSSFWorkbook(excelInputStream);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return workbook;
	}
}
