package com.ps.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ps.auth.service.AuthService;
import com.ps.dto.EvaluationDTO;
import com.ps.dto.UserDTO;
import com.ps.evaluation.service.EvaluationService;
import com.ps.util.MapperUtility;

@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	private AuthService authService;
	
	@Autowired
	private EvaluationService evaluationService;
	
	@Autowired
	private MapperUtility utility;
	
	@RequestMapping("/retrieveUsers")
	public List<UserDTO> getAllUsers()
	{
		return utility.convertUserEntitysToDtos(authService.retrieveAllUsersAndRoles());
	}
	@RequestMapping("/retrieveAssessmentByUser/{userId}")
	public List<EvaluationDTO> retrieveAssessmentByUserId(@PathVariable("userId") String userId)
	{
		return evaluationService.retrieveByUserId(userId);
	}
}
